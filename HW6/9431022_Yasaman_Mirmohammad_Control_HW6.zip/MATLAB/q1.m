
H = tf([10 0],[1 4 4 0]);
rlocus(H)