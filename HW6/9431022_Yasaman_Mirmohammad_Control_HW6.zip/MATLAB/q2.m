
H = tf(1,[1 6 11 6]);
bode(H)