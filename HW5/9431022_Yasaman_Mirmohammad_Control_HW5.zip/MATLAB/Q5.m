numg=poly(0);
deng=[1,2,1];
G=tf(numg,deng);
grid
rlocus(G)
z=0.5;
sgrid(z,0);
grid 