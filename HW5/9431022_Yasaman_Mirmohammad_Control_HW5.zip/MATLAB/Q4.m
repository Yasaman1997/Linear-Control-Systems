numg=poly(0);
deng=[5,0,4];
G=tf(numg,deng);
grid
rlocus(G)
z=0.5;
sgrid(z,0);
grid