function out= func(a, b)
out = sqrt(a.^2+b.^2);
